import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { apiProxyPlugin } from "./plugins/api-proxy-plugin";

// Inline Vite dev middleware for cub.rip proxy
export default defineConfig({
  plugins: [
    react(),
    apiProxyPlugin()
  ],
  server: {
    // The proxy is handled by the plugin, no need for middlewareMode here
    // middlewareMode: false,
  },
});

