// API proxy helper for forwarding requests to cub.rip/api/
export interface ApiRequest {
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: unknown;
}

export interface ApiResponse {
  success: boolean;
  data?: unknown;
  error?: string;
  status?: number;
}

export async function callCubApi(request: ApiRequest): Promise<ApiResponse> {
  try {
    const resp = await fetch("/api-proxy", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        endpoint: request.endpoint,
        method: request.method,
        headers: request.headers,
        payload: request.body,
      }),
    });
    const result = await resp.json();
    return {
      success: resp.ok && String(result.status).startsWith("2"),
      data: result.data,
      status: result.status,
      error: !resp.ok ? result.error : undefined,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}

// Predefined API calls matching the Postman collection
export const predefinedCalls = {
  'notifications-status': {
    endpoint: '/notifications/status',
    method: 'POST' as const,
    body: { id: '1', status: '1' },
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'profiles-all': {
    endpoint: '/profiles/all',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'reactions-add': {
    endpoint: '/reactions/add/tv_125988/fire',
    method: 'GET' as const,
    headers: {
      Profile: '',
      Token: '',
    },
  },
  'reactions-get': {
    endpoint: '/reactions/get/tv_125988',
    method: 'GET' as const,
    headers: {
      Profile: '',
      Token: '',
    },
  },
  'users-find': {
    endpoint: '/users/find?email=example@email.com',
    method: 'GET' as const,
    headers: {
      Profile: '',
      Token: '',
    },
  },
  'users-get': {
    endpoint: '/users/get',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'users-give': {
    endpoint: '/users/give',
    method: 'POST' as const,
    body: { to: '1', days: '30', password: 'password' },
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'bookmarks-all': {
    endpoint: '/bookmarks/all',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    // Example of how to add query parameters:
    // endpoint: '/bookmarks/all?full=1&type=book',
    // You can modify the endpoint dynamically in handleApiCall if needed, or create separate predefinedCalls
    // for specific queries like 'bookmarks-all-full' or 'bookmarks-all-book-type'.
  },
  'bookmarks-add': {
    endpoint: '/bookmarks/add',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    body: { id: 'example_id', type: 'example_type' }, // Example payload, adjust as needed
  },
  'bookmarks-remove': {
    endpoint: '/bookmarks/remove',
    method: 'DELETE' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    // body: { id: 'example_id' }, // Example payload, adjust as needed
  },
  'notice-all': {
    endpoint: '/notice/all',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'notice-clear': {
    endpoint: '/notice/clear',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'profiles-change': {
    endpoint: '/profiles/change',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    body: { id: 'new_profile_id', name: 'New Profile Name' }, // Example payload, adjust as needed
  },
  'profiles-create': {
    endpoint: '/profiles/create',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    body: { name: 'New Profile Name' }, // Example payload, adjust as needed
  },
  'profiles-remove': {
    endpoint: '/profiles/remove',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    body: { id: 'profile_to_remove_id' }, // Example payload, adjust as needed
  },
  'notifications-all': {
    endpoint: '/notifications/all',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'notifications-add': {
    endpoint: '/notifications/add',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    body: { type: 'example_type', message: 'Example message' }, // Example payload, adjust as needed
  },
  'device-add': {
    endpoint: '/device/add',
    method: 'POST' as const,
    headers: {
      // No authentication required
    },
    body: { device_id: 'your_device_id' }, // Example payload, adjust as needed
  },
  'card-subscribed': {
    endpoint: '/card/subscribed',
    method: 'GET' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
  },
  'notifications-remove': {
    endpoint: '/notifications/remove',
    method: 'POST' as const,
    headers: {
      Profile: '536380',
      Token: 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=',
    },
    // body: { id: 'notification_id_to_remove' }, // Example payload, adjust as needed
  },
};

