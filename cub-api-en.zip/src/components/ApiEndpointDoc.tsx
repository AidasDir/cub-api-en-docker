import React, { useState, useEffect } from "react";
import hljs from 'highlight.js';
import 'highlight.js/styles/default.css'; // You can choose a different theme here

interface ApiEndpointDocProps {
  title: string;
  description: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  queryParams?: { name: string; type: string; description: string; defaultValue?: string; options?: string[] }[];
  bodyParams?: { name: string; type: string; description: string; defaultValue?: string; options?: string[] }[];
  pathParams?: { name: string; type: string; description: string; defaultValue?: string; options?: string[] }[];
  errors?: { statusCode: number; description: string }[];
  note?: string;
  exampleResponse: string;
}

const ApiEndpointDoc: React.FC<ApiEndpointDocProps> = ({
  title,
  description,
  method,
  path,
  queryParams,
  bodyParams,
  pathParams,
  errors,
  note,
  exampleResponse,
}) => {
  const [token, setToken] = useState<string>('eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ='); // Real token value
  const [profile, setProfile] = useState<string>('536380'); // Real profile ID
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [bodyParamValues, setBodyParamValues] = useState<{ [key: string]: string }>({});
  const [pathParamValues, setPathParamValues] = useState<{ [key: string]: string }>({});
  const [queryParamValues, setQueryParamValues] = useState<{ [key: string]: string }>({});
  const [highlightedResponse, setHighlightedResponse] = useState<string | null>(null);
  const [httpStatus, setHttpStatus] = useState<number | null>(null);

  // Initialize bodyParamValues when bodyParams prop changes
  React.useEffect(() => {
    if (bodyParams) {
      const initialValues: { [key: string]: string } = {};
      bodyParams.forEach(param => {
        initialValues[param.name] = param.defaultValue || '';
      });
      setBodyParamValues(initialValues);
    }
  }, [bodyParams]);

  // Initialize pathParamValues when pathParams prop changes
  React.useEffect(() => {
    if (pathParams) {
      const initialValues: { [key: string]: string } = {};
      pathParams.forEach(param => {
        initialValues[param.name] = param.defaultValue || '';
      });
      setPathParamValues(initialValues);
    }
  }, [pathParams]);

  // Initialize queryParamValues when queryParams prop changes
  React.useEffect(() => {
    if (queryParams) {
      const initialValues: { [key: string]: string } = {};
      queryParams.forEach(param => {
        initialValues[param.name] = param.defaultValue || '';
      });
      setQueryParamValues(initialValues);
    }
  }, [queryParams]);

  // Apply syntax highlighting to response
  React.useEffect(() => {
    if (response) {
      try {
        // Attempt to parse as JSON for highlighting
        const parsedJson = JSON.parse(response);
        const formattedJson = JSON.stringify(parsedJson, null, 2);
        const highlightedCode = hljs.highlight(formattedJson, {language: 'json'}).value;
        setHighlightedResponse(highlightedCode);
        console.log("Highlighted Response:", highlightedCode);
      } catch (e) {
        // If not valid JSON, display as plain text
        setHighlightedResponse(response);
        console.log("Non-JSON Response:", response);
      }
    } else {
      setHighlightedResponse(null);
    } 
  }, [response]);

  const handleBodyParamChange = (name: string, value: string) => {
    setBodyParamValues((prev: {[key: string]: string}) => ({ ...prev, [name]: value }));
  };

  const handlePathParamChange = (name: string, value: string) => {
    setPathParamValues((prev: {[key: string]: string}) => ({ ...prev, [name]: value }));
  };

  const handleQueryParamChange = (name: string, value: string) => {
    setQueryParamValues((prev: {[key: string]: string}) => ({ ...prev, [name]: value }));
  };

  const handleSendRequest = async () => {
    setLoading(true);
    setResponse(null);

    let constructedPath = path;
    if (pathParams) {
      pathParams.forEach(param => {
        constructedPath = constructedPath.replace(`{${param.name}}`, pathParamValues[param.name] || param.defaultValue || '');
      });
    }

    if (queryParams) {
      const queryString = new URLSearchParams();
      queryParams.forEach(param => {
        const paramValue = queryParamValues[param.name] || param.defaultValue || '';
        if (paramValue) {
          queryString.append(param.name, paramValue);
        }
      });
      if (queryString.toString()) {
        constructedPath += `?${queryString.toString()}`;
      }
    }

    // Construct the request body for the proxy
    const requestBody: any = {
      endpoint: constructedPath,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'Profile': profile,
        'Token': token,
      },
      payload: (method !== 'GET' && bodyParams) ? bodyParamValues : undefined,
    };

    try {
      const resp = await fetch("/api-proxy", {
        method: "POST", // Always POST to our proxy
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      setHttpStatus(resp.status);
      const result = await resp.json();
      // Check if the response has a 'data' field and use it, otherwise use the full result
      if (result && typeof result === 'object' && 'data' in result) {
        setResponse(JSON.stringify(result.data, null, 2));
      } else {
        setResponse(JSON.stringify(result, null, 2));
      }
    } catch (error) {
      setResponse(`Error: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="mb-10 max-w-full overflow-hidden">
      <div className="text-sm text-[#999998] uppercase font-mono mb-1">#{title.split(' ')[0]}</div>
      <h1 className="text-3xl font-extrabold mb-2">{title}</h1>
      <p className="text-base max-w-2xl text-gray-700 mb-4">{description}</p>

      <div className="flex items-center space-x-2 mb-6">
        <span className={`px-2 py-1 rounded text-xs font-semibold ${method === 'GET' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
          {method}
        </span>
        <code className="font-mono text-sm text-gray-800 px-2 py-1 bg-gray-200 rounded">{path}</code>
      </div>

      {queryParams && queryParams.length > 0 && (
        <>
          <h3 className="font-bold mb-4 text-[#252425] uppercase text-sm tracking-wider">QUERY PARAMS</h3>
          <div className="border border-gray-200 rounded-lg shadow-sm mb-6">
            <div className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm font-semibold text-gray-600 bg-gray-100 rounded-t-lg p-4 border-b border-gray-200">
              <div className="text-[#252425] font-bold">Name</div>
              <div>Type</div>
              <div>Description</div>
              <div className="text-right">Value</div>
            </div>
            {queryParams.map((param, index) => (
              <div key={index} className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm text-gray-700 py-2 px-4 border-b border-gray-100 last:border-b-0">
                <code className="font-mono font-bold text-[#252425]">{param.name}</code>
                <span className="font-mono text-gray-600">{param.type}</span>
                <div>
                  {param.description.includes('required') ? (
                    <>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[0] }} />
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 ml-1">
                        required
                      </span>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[1] }} />
                    </>
                  ) : (
                    <span dangerouslySetInnerHTML={{ __html: param.description }} />
                  )}
                  {param.options && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {param.options.map((option, optIndex) => (
                        <span key={optIndex} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs cursor-pointer hover:bg-gray-200">
                          {option}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <input
                    type={param.type === 'integer' ? 'number' : 'text'}
                    value={queryParamValues[param.name] || ''}
                    onChange={(e) => handleQueryParamChange(param.name, e.target.value)}
                    className="w-full max-w-[200px] px-2 py-1 border border-gray-300 rounded text-sm text-gray-800 font-mono focus:ring-green-500 focus:border-green-500"
                    placeholder={param.defaultValue}
                  />
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {bodyParams && bodyParams.length > 0 && (
        <>
          <h3 className="font-bold mb-4 text-[#252425] uppercase text-sm tracking-wider">BODY PARAMS</h3>
          <div className="border border-gray-200 rounded-lg shadow-sm mb-6">
            <div className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm font-semibold text-gray-600 bg-gray-100 rounded-t-lg p-4 border-b border-gray-200">
              <div className="text-[#252425] font-bold">Name</div>
              <div>Type</div>
              <div>Description</div>
              <div className="text-right">Value</div>
            </div>
            {bodyParams.map((param, index) => (
              <div key={index} className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm text-gray-700 py-2 px-4 border-b border-gray-100 last:border-b-0">
                <code className="font-mono font-bold text-[#252425]">{param.name}</code>
                <span className="font-mono text-gray-600">{param.type}</span>
                <div>
                  {param.description.includes('required') ? (
                    <>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[0] }} />
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 ml-1">
                        required
                      </span>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[1] }} />
                    </>
                  ) : (
                    <span dangerouslySetInnerHTML={{ __html: param.description }} />
                  )}
                  {param.options && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {param.options.map((option, optIndex) => (
                        <span key={optIndex} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs cursor-pointer hover:bg-gray-200">
                          {option}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <input
                    type={param.type === 'integer' ? 'number' : 'text'}
                    value={bodyParamValues[param.name] || ''}
                    onChange={(e) => handleBodyParamChange(param.name, e.target.value)}
                    className="w-full max-w-[200px] px-2 py-1 border border-gray-300 rounded text-sm text-gray-800 font-mono focus:ring-green-500 focus:border-green-500"
                    placeholder={param.defaultValue}
                  />
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {pathParams && pathParams.length > 0 && (
        <>
          <h3 className="font-bold mb-4 text-[#252425] uppercase text-sm tracking-wider">PATH PARAMS</h3>
          <div className="border border-gray-200 rounded-lg shadow-sm mb-6">
            <div className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm font-semibold text-gray-600 bg-gray-100 rounded-t-lg p-4 border-b border-gray-200">
              <div className="text-[#252425] font-bold">Name</div>
              <div>Type</div>
              <div>Description</div>
              <div className="text-right">Value</div>
            </div>
            {pathParams.map((param, index) => (
              <div key={index} className="grid grid-cols-[0.8fr_0.8fr_6fr_1.2fr] gap-4 text-sm text-gray-700 py-2 px-4 border-b border-gray-100 last:border-b-0">
                <code className="font-mono font-bold text-[#252425]">{param.name}</code>
                <span className="font-mono text-gray-600">{param.type}</span>
                <div>
                  {param.description.includes('required') ? (
                    <>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[0] }} />
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 ml-1">
                        required
                      </span>
                      <span dangerouslySetInnerHTML={{ __html: param.description.split('required')[1] }} />
                    </>
                  ) : (
                    <span dangerouslySetInnerHTML={{ __html: param.description }} />
                  )}
                  {param.options && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {param.options.map((option, optIndex) => (
                        <span key={optIndex} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs cursor-pointer hover:bg-gray-200">
                          {option}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <input
                    type={param.type === 'integer' ? 'number' : 'text'}
                    value={pathParamValues[param.name] || ''}
                    onChange={(e) => handlePathParamChange(param.name, e.target.value)}
                    className="w-full max-w-[200px] px-2 py-1 border border-gray-300 rounded text-sm text-gray-800 font-mono focus:ring-green-500 focus:border-green-500"
                    placeholder={param.defaultValue}
                  />
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {errors && errors.length > 0 && (
        <>
          <h3 className="font-bold mb-4 text-[#252425] uppercase text-sm tracking-wider">ERRORS</h3>
          <div className="border border-gray-200 rounded-lg shadow-sm mb-6">
            <div className="grid grid-cols-[auto_6fr] gap-4 text-sm font-semibold text-gray-600 bg-gray-100 rounded-t-lg p-4 border-b border-gray-200">
              <div className="text-[#252425] font-bold">Status Code</div>
              <div>Description</div>
            </div>
            {errors.map((error, index) => (
              <div key={index} className="grid grid-cols-[auto_6fr] gap-4 text-sm text-gray-700 py-2 px-4 border-b border-gray-100 last:border-b-0">
                <span className="px-2 py-1 rounded text-xs font-semibold bg-red-200 text-red-800">{error.statusCode}</span>
                <div>{error.description}</div>
              </div>
            ))}
          </div>
        </>
      )}

      {note && (
        <div className="rounded border border-[rgb(123,121,255)] bg-[rgb(238,237,255)] p-4 w-full mb-6">
          <p className="text-sm mb-1 text-[rgb(74,74,106)]">{note}</p>
          <p className="text-xs text-[rgb(74,74,106)]">To do this, please enter your token. If you don't have one, you can <a href="#device-add" className="underline text-[rgb(74,74,106)]">get it here</a>.</p>
        </div>
      )}

      <h3 className="text-xl font-bold mb-4 mt-6">RESPONSE</h3>
      <div className="border border-gray-200 rounded-lg shadow-sm">
        {/* Token and Profile input row with Send Request button */}
        <div className="flex items-center space-x-2 p-4">
          <span className="px-2 py-1 rounded text-xs font-semibold bg-gray-200 text-gray-800">TOKEN</span>
          <input
            id="token-input"
            type="text"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm font-mono focus:ring-green-500 focus:border-green-500"
            placeholder="YOUR_ACCESS_TOKEN"
          />
          <span className="px-2 py-1 rounded text-xs font-semibold bg-gray-200 text-gray-800">PROFILE</span>
          <input
            id="profile-input"
            type="text"
            value={profile}
            onChange={(e) => setProfile(e.target.value)}
            className="w-24 px-3 py-2 border border-gray-300 rounded text-sm font-mono focus:ring-green-500 focus:border-green-500"
            placeholder="YOUR_PROFILE_ID"
          />
          <button
            onClick={handleSendRequest}
            disabled={loading}
            className="bg-[#252425] text-white px-5 py-2 rounded text-sm font-semibold hover:bg-gray-800 disabled:opacity-50"
          >
            {loading ? 'Sending...' : 'Send Request'}
          </button>
        </div>
        
        {/* Response display */}
        {response && (
          <div className="p-4 bg-gray-50 rounded-b-lg w-full border-t border-gray-100">
            <div className="flex items-center space-x-2 mb-3">
              <span className={`px-2 py-0.5 rounded text-xs font-semibold ${httpStatus && httpStatus >= 200 && httpStatus < 300 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                {httpStatus}
              </span>
              <span className="font-mono text-xs text-gray-600">application/json</span>
            </div>
            <pre className="whitespace-pre-wrap text-xs max-h-64 font-mono text-gray-800 max-w-full break-all break-words overflow-y-auto hljs language-json"
              dangerouslySetInnerHTML={{ __html: highlightedResponse || '' }}>
            </pre>
          </div>
        )}
      </div>
    </section>
  );
};

export default ApiEndpointDoc; 