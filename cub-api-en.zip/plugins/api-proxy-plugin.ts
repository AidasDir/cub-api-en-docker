import type { IncomingMessage, ServerResponse } from 'http';
import type { ViteDevServer } from 'vite';
import type { NextHandleFunction } from 'connect';

export function apiProxyPlugin() {
  return {
    name: 'api-proxy',
    configureServer(server: ViteDevServer) {
      server.middlewares.use(async (req: IncomingMessage, res: ServerResponse, next: () => void) => {
        const url = req.url || '';
        if (req.method === 'OPTIONS') {
          res.writeHead(200, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Profile, Token',
          });
          res.end();
          return;
        }

        if (!url.startsWith('/api-proxy') || req.method !== 'POST') {
          return next();
        }

        let bodyRaw = '';
        req.on('data', (chunk: Buffer | string) => { bodyRaw += chunk; });
        req.on('end', async () => {
          try {
            const { endpoint, method, headers, payload } = JSON.parse(bodyRaw);
            console.log('Proxy received:', { endpoint, method, headers, payload });

            // Profile/Token setup
            const profile = headers?.Profile || '536380';
            const tokenValue = headers?.Token || 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=';

            const cubHeaders: Record<string, string> = {
              'Content-Type': 'application/json',
              'Accept': '*/*',
              ...headers,
            };

            // Ensure Profile header is set
            cubHeaders['Profile'] = profile;

            // If a token was provided, set it as a Cookie and also ensure Token header is present
            if (tokenValue) {
              cubHeaders['Token'] = tokenValue;
            }

            const cubResp = await fetch(`https://cub.rip/api${endpoint}`, {
              method,
              headers: cubHeaders,
              body: method === 'GET' ? undefined : JSON.stringify(payload),
            });
            let data;
            try {
              data = await cubResp.json();
            } catch {
              data = await cubResp.text();
            }
            res.writeHead(cubResp.status, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ status: cubResp.status, data }));
          } catch (e) {
            res.writeHead(500);
            res.end(
              JSON.stringify({ error: e instanceof Error ? e.message : String(e) })
            );
          }
        });
      });
    },
  };
} 