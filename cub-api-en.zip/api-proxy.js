import { createServer } from "http";
import { parse } from "url";

// Simple proxy for cub.rip/api/ requests
const PORT = 8787;

// Only allow POST to /api-proxy
createServer(async (req, res) => {
  const { pathname } = parse(req.url || "");

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS' && pathname === '/api-proxy') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Profile, Token',
    });
    res.end();
    return;
  }

  if (pathname !== "/api-proxy" || req.method !== "POST") {
    res.writeHead(404);
    res.end();
    return;
  }

  let body = "";
  req.on("data", chunk => { body += chunk; });
  req.on("end", async () => {
    try {
      const { endpoint, method, headers, payload } = JSON.parse(body);
      // Always enforce Profile + token cookie
      const profile = headers?.Profile || '536380';
      const token = headers?.Token || 'eyJpZCI6NTIwNjg4LCJoYXNoIjoiIn0=.avFLylZCLSIn7k+SLdM5ZXpK+2NzSpSxBxnY4i7VpiQ=';
      const cubHeaders = {
        "Profile": profile,
        "Cookie": `token=${token}`,
        ...headers,
      };
      // Remove any accidental Token/Cookie keys (we manually control)
      delete cubHeaders.Token;
      delete cubHeaders.Cookie;
      // Always set required headers
      cubHeaders['Content-Type'] = 'application/json';
      cubHeaders['Accept'] = '*/*';

      const result = await fetch(`https://cub.rip/api${endpoint}`, {
        method,
        headers: cubHeaders,
        body: method === 'GET' ? undefined : JSON.stringify(payload)
      });
      let data;
      try {
        data = await result.json();
      } catch {
        data = await result.text();
      }
      res.writeHead(result.status, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ status: result.status, data }));
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ error: (e instanceof Error ? e.message : String(e)) }));
    }
  });
}).listen(PORT);

console.log(`[proxy] Running at http://localhost:${PORT}/api-proxy`);

